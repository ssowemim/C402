/**
 * Created by awaseem on 15-06-29.
 */

Questions = new Mongo.Collection("questions");

Choices = new Mongo.Collection("choices");

Responses = new Mongo.Collection("responses");

clientAddress = new Mongo.Collection("clientAddress");