# votetell.com

A poll creator that allows users to vote and also send a custom response to the creator. 

Made with Meteor JS and Semantic UI.

## Setup 

To run just simply use the command: 

`meteor` 




